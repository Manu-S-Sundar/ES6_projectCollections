//define constants, objects and all from here
const navItems = ['ArraySort', 'RemoveDuplicate','PopulateTable','promise'];
//function block
createElement = ( elementType ) => document.createElement( elementType );
createElementContent = ( content ) => document.createTextNode( content );
createNavItem = ( itemName, className ) => {
	let nav = createElement( 'div' );
	let navItem = createElementContent( itemName );
	nav.appendChild( navItem );
	if( className ){
		nav.classList.add( className );
	}
	console.log( nav )
	document.getElementById( 'nav' ).appendChild( nav )
}

//business flow 
//TODO: call a method to read a json file and get the value of navItems then pass to the loop
for( let i=0; i<navItems.length; i++ ){
	//create navigation menu items 
	createNavItem( navItems[i],'navItems' );
}

var data = { firstName: 'John', lastName: 'Doe', email: 'john.doe@gmail.com' }
var output = Object.entries(data).map(([key, value]) => ({key,value}));

output.forEach(function(item){
	console.log(item)
});




